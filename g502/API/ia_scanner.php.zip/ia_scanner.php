<?php
/**
 * G502 - Smart IA Scanner con Google Vision
 * Proyecto: Nexus g502
 */

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/db.php'; 

$errorMsg = ""; 
$successMsg = "";
$extractedData = []; 
$apiKey = 'AIzaSyASQrEmVic42WIewPvDzO3J2uG4qugRHaY'; 

if (isset($_POST['scan'])) {
    if (!isset($_FILES['fileToScan']) || $_FILES['fileToScan']['error'] == UPLOAD_ERR_NO_FILE) {
        $errorMsg = "❌ Por favor, selecciona un archivo primero.";
    } else {
        $tempFile = $_FILES['fileToScan']['tmp_name'];
        $fileType = $_FILES['fileToScan']['type'];

        // ─── PDF: todas las páginas ───────────────────────────────────────────
        if ($fileType == 'application/pdf') {
            if (!class_exists('Imagick')) {
                $errorMsg = "❌ El servidor no tiene Imagick instalado.";
            } else {
                try {
                    $imgCount = new Imagick();
                    $imgCount->pingImage($tempFile);
                    $totalPages = $imgCount->getNumberImages();
                    $imgCount->destroy();

                    $stmt = $conn->prepare("INSERT INTO productos_ia (name, plu_code, category, quantity, description, state, tipo) VALUES (?, ?, ?, ?, ?, ?, ?)");

                    for ($page = 0; $page < $totalPages; $page++) {
                        $img = new Imagick();
                        $img->setResolution(300, 300);
                        $img->readImage($tempFile . '[' . $page . ']');
                        $img->setImageFormat('jpg');
                        $img->setImageAlphaChannel(Imagick::ALPHACHANNEL_REMOVE);
                        $img->mergeImageLayers(Imagick::LAYERMETHOD_FLATTEN);
                        $imageData = base64_encode($img->getImageBlob());
                        $img->destroy();

                        $payload = json_encode([
                            "requests" => [[
                                "image" => ["content" => $imageData],
                                "features" => [["type" => "TEXT_DETECTION"]],
                                "imageContext" => ["languageHints" => ["es"]]
                            ]]
                        ]);

                        $ch = curl_init("https://vision.googleapis.com/v1/images:annotate?key=" . $apiKey);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
                        $resData = json_decode(curl_exec($ch), true);
                        curl_close($ch);

                        if (!isset($resData['responses'][0]['fullTextAnnotation']['text'])) continue;

                        $lines = explode("\n", $resData['responses'][0]['fullTextAnnotation']['text']);

                        foreach ($lines as $linea) {
                            $linea = trim($linea);
                            if (preg_match('/NIT|TEL|FECHA|TOTAL|IVA|FACTURA|C\.C|PAGINA/i', $linea)) continue;

                            if (preg_match('/\b(\d{4,15})\b/', $linea, $m)) {
                                $plu = $m[1];
                                if (preg_match('/^(800|890|900|901)/', $plu) && strlen($plu) > 8) continue;
                                if (in_array($plu, array_column($extractedData, 'plu'))) continue;

                                $name = trim(preg_replace('/[:\-_|.]/', '', str_replace($plu, '', $linea)));
                                if (strlen($name) < 3) $name = "Producto Desconocido ($plu)";

                                $extractedData[] = ['plu' => $plu, 'nombre' => $name];

                                $cat = 'General'; $qty = 1; $desc = 'Escaneado por IA G502'; $st = 'Activo'; $tipo = 'PDF';
                                $stmt->bind_param("sssisss", $name, $plu, $cat, $qty, $desc, $st, $tipo);
                                $stmt->execute();
                            }
                        }
                    }

                    $stmt->close();
                    $successMsg = "✅ " . count($extractedData) . " productos detectados en $totalPages página(s).";

                } catch (Exception $e) {
                    $errorMsg = "❌ Error procesando PDF: " . $e->getMessage();
                }
            }

        // ─── IMAGEN ───────────────────────────────────────────────────────────
        } else {
            $imageData = base64_encode(file_get_contents($tempFile));

            $payload = json_encode([
                "requests" => [[
                    "image" => ["content" => $imageData],
                    "features" => [["type" => "TEXT_DETECTION"]],
                    "imageContext" => ["languageHints" => ["es"]]
                ]]
            ]);

            $ch = curl_init("https://vision.googleapis.com/v1/images:annotate?key=" . $apiKey);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            $resData = json_decode(curl_exec($ch), true);
            curl_close($ch);

            if (isset($resData['responses'][0]['fullTextAnnotation']['text'])) {
                $lines = explode("\n", $resData['responses'][0]['fullTextAnnotation']['text']);

                $stmt = $conn->prepare("INSERT INTO productos_ia (name, plu_code, category, quantity, description, state, tipo) VALUES (?, ?, ?, ?, ?, ?, ?)");

                foreach ($lines as $linea) {
                    $linea = trim($linea);
                    if (preg_match('/NIT|TEL|FECHA|TOTAL|IVA|FACTURA|C\.C|PAGINA/i', $linea)) continue;

                    if (preg_match('/\b(\d{4,15})\b/', $linea, $m)) {
                        $plu = $m[1];
                        if (preg_match('/^(800|890|900|901)/', $plu) && strlen($plu) > 8) continue;
                        if (in_array($plu, array_column($extractedData, 'plu'))) continue;

                        $name = trim(preg_replace('/[:\-_|.]/', '', str_replace($plu, '', $linea)));
                        if (strlen($name) < 3) $name = "Producto Desconocido ($plu)";

                        $extractedData[] = ['plu' => $plu, 'nombre' => $name];

                        $cat = 'General'; $qty = 1; $desc = 'Escaneado por IA G502'; $st = 'Activo'; $tipo = 'IMG';
                        $stmt->bind_param("sssisss", $name, $plu, $cat, $qty, $desc, $st, $tipo);
                        $stmt->execute();
                    }
                }

                $stmt->close();
                $successMsg = "✅ " . count($extractedData) . " productos detectados.";
            } else {
                $errorMsg = "⚠️ No se detectó texto legible.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>G502 | IA Smart Scanner</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
    <style>
        :root { --primary: #2563eb; --bg: #f1f5f9; --text: #0f172a; --accent: #10b981; }
        body { font-family: 'Inter', sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 15px; }
        .container { max-width: 600px; margin: auto; }
        .card { background: white; padding: 20px; border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); margin-bottom: 15px; }
        h1 { font-size: 1.5rem; text-align: center; margin-bottom: 5px; }
        .header-desc { text-align: center; color: #64748b; font-size: 0.9rem; margin-bottom: 20px; }
        
        .btn { padding: 12px 20px; border-radius: 10px; border: none; cursor: pointer; font-weight: 600; transition: 0.2s; font-size: 14px; }
        .btn-primary { background: var(--primary); color: white; width: 100%; display: block; }
        .btn-outline { background: #f8fafc; border: 1px solid #e2e8f0; color: #475569; }
        .btn-copy { background: var(--accent); color: white; }
        
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; font-size: 12px; color: #64748b; text-transform: uppercase; padding: 10px; }
        td { padding: 12px 10px; border-top: 1px solid #f1f5f9; }
        .badge { background: #e2e8f0; padding: 4px 8px; border-radius: 6px; font-family: 'Courier New', monospace; font-weight: 700; }

        /* MODAL */
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); justify-content: center; align-items: center; backdrop-filter: blur(4px); }
        .modal-content { background: white; padding: 25px; border-radius: 24px; width: 90%; max-width: 400px; text-align: center; }
        .barcode-view { background: white; padding: 15px; border-radius: 12px; border: 1px solid #e2e8f0; margin: 15px 0; }
        #barcode { width: 100%; height: auto; }
        .plu-large { font-size: 2.5rem; font-weight: 800; margin: 10px 0; letter-spacing: 2px; }

        /* Responsividad Móvil */
        @media (max-width: 480px) {
            table, thead, tbody, th, td, tr { display: block; }
            thead tr { position: absolute; top: -9999px; }
            tr { margin-bottom: 15px; border: 1px solid #e2e8f0; border-radius: 12px; background: white; padding: 10px; }
            td { border: none; display: flex; justify-content: space-between; align-items: center; padding: 5px; }
            td::before { content: attr(data-label); font-weight: 600; font-size: 11px; color: #94a3b8; }
            .btn-group { width: 100%; display: flex; gap: 8px; margin-top: 10px; }
            .btn-group button { flex: 1; }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="card" style="text-align: center;">
        <h1>🚀 g502 Smart IA</h1>
        <p class="header-desc">Scanner de Facturas y Generador de Barras</p>
        
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="fileToScan" id="file" accept="image/*,application/pdf" hidden required>
            <label for="file" class="btn btn-outline" style="display:block; margin-bottom:10px;">📁 Seleccionar Archivo</label>
            <button type="submit" name="scan" class="btn btn-primary">🔍 Iniciar Escaneo</button>
        </form>
    </div>

    <?php if ($errorMsg): ?> <div style="color:#b91c1c; background:#fee2e2; padding:12px; border-radius:10px; margin-bottom:10px;"><?php echo $errorMsg; ?></div> <?php endif; ?>
    <?php if ($successMsg): ?> <div style="color:#15803d; background:#dcfce7; padding:12px; border-radius:10px; margin-bottom:10px;"><?php echo $successMsg; ?></div> <?php endif; ?>

    <?php if (!empty($extractedData)): ?>
    <div class="card" style="padding:0;">
        <table>
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Producto</th>
                    <th>Acciones</th>
                    <th>Subir</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($extractedData as $p): ?>
                <tr>
                    <td data-label="CÓDIGO"><span class="badge"><?php echo $p['plu']; ?></span></td>
                    <td data-label="PRODUCTO" style="font-size:13px; font-weight:600;"><?php echo htmlspecialchars($p['nombre']); ?></td>
                    <td data-label="OPCIONES">
                        <div class="btn-group">
                            <button class="btn btn-outline" onclick="openBarcode('<?php echo $p['plu']; ?>')">👁️</button>
                            <button class="btn btn-copy" onclick="copyText('<?php echo $p['plu']; ?>', this)">📋</button>
                        </div>
                    </td>
                    <td data-label="SUBIR">
    <input type="checkbox" value="<?php echo htmlspecialchars($p['plu']); ?>" class="product-check" style="width:18px; height:18px; cursor:pointer;">
</td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<!-- Modal para Código de Barras -->
<div id="barcodeModal" class="modal">
    <div class="modal-content">
        <h2 style="margin:0; font-size:1.2rem;">Visor g502</h2>
        <div style="display:flex; gap:5px; margin: 15px 0;">
            <button class="btn btn-primary" style="font-size:11px;" onclick="render('CODE128')">Standard</button>
            <button class="btn btn-primary" style="font-size:11px; background:#f59e0b;" onclick="render('EAN13')">Panadería</button>
        </div>
        <div class="barcode-view">
            <svg id="barcode"></svg>
            <div id="pluLabel" class="plu-large"></div>
        </div>
        <button class="btn btn-outline" style="width:100%;" onclick="closeModal()">Cerrar</button>
    </div>
</div>

<script>
let currentCode = "";

function openBarcode(code) {
    currentCode = String(code).trim();
    document.getElementById('barcodeModal').style.display = 'flex';
    
    // Decidimos el formato inicial: si tiene 12-13 dígitos, intentamos EAN13, si no, CODE128
    let format = (currentCode.length >= 12 && !isNaN(currentCode)) ? 'EAN13' : 'CODE128';
    render(format);
}

function render(type) {
    // Limpiamos el código de cualquier carácter no numérico para el renderizado
    let codeToRender = currentCode.replace(/\D/g, ''); 
    
    // Lógica especial para EAN13 (Estándar de retail)
    if (type === 'EAN13') {
        if (codeToRender.length < 13) {
            codeToRender = codeToRender.padStart(13, '0');
        } else if (codeToRender.length > 13) {
            codeToRender = codeToRender.substring(0, 13);
        }
    }

    try {
        JsBarcode("#barcode", codeToRender, {
            format: type,
            width: 2.5,
            height: 70,
            displayValue: false, // Ocultamos el valor de la librería para usar nuestro label grande
            fontSize: 20,
            // Si el EAN13 es inválido (por el dígito de control), JsBarcode lanzará un error
            valid: function(valid) {
                if (!valid && type === 'EAN13') {
                    console.warn("EAN13 inválido (Checksum incorrecto). Cambiando a CODE128.");
                    render('CODE128'); 
                }
            }
        });
        
        document.getElementById('pluLabel').innerText = codeToRender;
        
    } catch (e) {
        // Fallback total: Si falla cualquier formato, el CODE128 nunca falla
        console.error("Error renderizando. Forzando CODE128.");
        JsBarcode("#barcode", codeToRender, {
            format: "CODE128",
            width: 2.5,
            height: 70,
            displayValue: false
        });
        document.getElementById('pluLabel').innerText = codeToRender;
    }
}

function closeModal() {
    document.getElementById('barcodeModal').style.display = 'none';
}

function copyText(text, btn) {
    navigator.clipboard.writeText(text).then(() => {
        const old = btn.innerHTML;
        btn.innerHTML = "✅";
        setTimeout(() => btn.innerHTML = old, 1000);
    });
}

// Cerrar modal al hacer click fuera de la caja blanca
window.onclick = function(e) {
    if (e.target.id === 'barcodeModal') closeModal();
}
</script>

</body>
</html>